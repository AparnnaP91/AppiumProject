package AppiumProject.ERIBankTestCase;

import AppiumProject.ERIBankPages.LoginPage;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;

public class LoginSteps 
{
	AppiumProject.ERIBankPages.LoginPage loginpage;
	@Given("^User is on the login page$")
	public void OpenLoginPage()
	{
		loginpage=new LoginPage("Android");
	}
	
	@When("^User enters \"company\" in UserName field$")
	public void EnterUserName()
	{
		AppiumProject.ERIBankPages.LoginPage.EnterUserName("Aparnna");
	}
	
	@When("^User enters \"company\" in Password field$")
	public void EnterPassword()
	{
		AppiumProject.ERIBankPages.LoginPage.EnterPassword("company");
	}
	
	@When("^User clicks on Login button$")
	public void ClickLoginButton()
	{
		AppiumProject.ERIBankPages.LoginPage.ClickLoginButton();
	}
	@Then("^User should be able to login successfully$")
	public void CheckLogin()
	{
		
	}
}
